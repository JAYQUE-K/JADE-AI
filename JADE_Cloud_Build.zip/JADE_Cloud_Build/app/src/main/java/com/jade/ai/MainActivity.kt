package com.jade.ai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val JadeBg = Color(0xFF07110D)
private val JadePanel = Color(0xFF101D17)
private val JadeGreen = Color(0xFF39D98A)
private val JadeText = Color(0xFFE8F4ED)
private val JadeMuted = Color(0xFF9AB0A2)

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    private var onModelSelected: ((Uri) -> Unit)? = null
    private val modelPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            catch (_: Exception) {}
            onModelSelected?.invoke(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var modelUri by remember { mutableStateOf<Uri?>(null) }
            var input by remember { mutableStateOf("") }
            var showInfo by remember { mutableStateOf(false) }
            val messages = remember {
                mutableStateListOf(
                    ChatMessage("Hi, I'm JADE. Your private AI workspace is ready.", false),
                    ChatMessage("Choose a local GGUF model to prepare this device. The inference engine is not yet connected in this starter build.", false)
                )
            }
            onModelSelected = { modelUri = it }
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = JadeGreen,
                    background = JadeBg,
                    surface = JadePanel,
                    onBackground = JadeText,
                    onSurface = JadeText
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = JadeBg) {
                    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                        Header(onSettings = { showInfo = true })
                        ModelBanner(
                            modelName = modelUri?.lastPathSegment?.substringAfterLast(":") ?: "No model selected",
                            loaded = false,
                            onPick = { modelPicker.launch(arrayOf("*/*")) }
                        )
                        LazyColumn(
                            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
                            contentPadding = PaddingValues(vertical = 18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            item {
                                Text("YOUR LOCAL AI", color = JadeMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            }
                            items(messages) { msg -> MessageBubble(msg) }
                        }
                        SuggestionRow { prompt -> input = prompt }
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp)
                                .background(JadePanel, RoundedCornerShape(24.dp)).padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { modelPicker.launch(arrayOf("*/*")) }) {
                                Icon(Icons.Default.AttachFile, contentDescription = "Choose model", tint = JadeMuted)
                            }
                            TextField(
                                value = input,
                                onValueChange = { input = it },
                                modifier = Modifier.weight(1f),
                                placeholder = { Text("Ask JADE anything...", color = JadeMuted) },
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent,
                                    focusedTextColor = JadeText,
                                    unfocusedTextColor = JadeText
                                ),
                                maxLines = 4
                            )
                            IconButton(onClick = {
                                val q = input.trim()
                                if (q.isNotEmpty()) {
                                    messages.add(ChatMessage(q, true))
                                    messages.add(ChatMessage(
                                        if (modelUri == null)
                                            "Select a local .gguf model first. This starter currently provides the app shell; local model inference will be enabled in the next integration step."
                                        else
                                            "Model file selected. Inference is not connected yet, so I can't generate a real model answer in this build.",
                                        false
                                    ))
                                    input = ""
                                }
                            }) {
                                Icon(Icons.Default.Send, contentDescription = "Send", tint = JadeGreen)
                            }
                        }
                        Text(
                            "PRIVATE BY DESIGN  •  OFFLINE UI STARTER",
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                            color = JadeMuted, fontSize = 9.sp, letterSpacing = 1.4.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
                if (showInfo) {
                    AlertDialog(
                        onDismissRequest = { showInfo = false },
                        title = { Text("JADE — build status") },
                        text = { Text("Milestone 1: Android app shell and local file picker.\\n\\nNot yet implemented: llama.cpp inference, document indexing, image understanding, speech, or image generation. The app does not upload your files.") },
                        confirmButton = { TextButton(onClick = { showInfo = false }) { Text("OK") } },
                        containerColor = JadePanel
                    )
                }
            }
        }
    }
}

@Composable
private fun Header(onSettings: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(42.dp).background(JadeGreen.copy(alpha = 0.14f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.SmartToy, contentDescription = null, tint = JadeGreen, modifier = Modifier.size(25.dp))
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text("JADE", color = JadeText, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
            Text("LOCAL INTELLIGENCE", color = JadeMuted, fontSize = 9.sp, letterSpacing = 2.sp)
        }
        IconButton(onClick = onSettings) {
            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = JadeMuted)
        }
    }
}

@Composable
private fun ModelBanner(modelName: String, loaded: Boolean, onPick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp).background(JadePanel, RoundedCornerShape(16.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Memory, contentDescription = null, tint = JadeGreen, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(if (loaded) "MODEL READY" else "LOCAL MODEL", color = JadeGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Text(modelName, color = JadeText, fontSize = 12.sp, maxLines = 1)
            Text(if (loaded) "Ready for offline inference" else "Not loaded · inference integration pending", color = JadeMuted, fontSize = 10.sp)
        }
        TextButton(onClick = onPick) { Text("Choose") }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier.widthIn(max = 310.dp)
                .background(if (message.fromUser) Color(0xFF164A32) else JadePanel, RoundedCornerShape(18.dp))
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            Text(if (message.fromUser) "YOU" else "JADE", color = if (message.fromUser) JadeGreen else JadeMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
            Spacer(Modifier.height(5.dp))
            Text(message.text, color = JadeText, fontSize = 14.sp, lineHeight = 20.sp)
        }
    }
}

@Composable
private fun SuggestionRow(onChoose: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        SuggestionChip("Solve maths", Modifier.weight(1f), onChoose)
        SuggestionChip("Explain science", Modifier.weight(1f), onChoose)
        SuggestionChip("Help code", Modifier.weight(1f), onChoose)
    }
}

@Composable
private fun SuggestionChip(label: String, modifier: Modifier, onChoose: (String) -> Unit) {
    AssistChip(
        onClick = { onChoose(when (label) {
            "Solve maths" -> "Explain and solve this math problem step by step: "
            "Explain science" -> "Explain this science concept clearly: "
            else -> "Help me write and understand code for: "
        }) },
        label = { Text(label, fontSize = 10.sp, maxLines = 1) },
        modifier = modifier,
        colors = AssistChipDefaults.assistChipColors(
            containerColor = JadePanel,
            labelColor = JadeText
        )
    )
}
