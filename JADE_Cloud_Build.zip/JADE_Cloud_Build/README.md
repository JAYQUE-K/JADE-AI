# JADE Android Starter — Cloud APK Build

This is a starter Android app with a dark emerald Compose interface and a GitHub Actions workflow that compiles a **debug APK in the cloud**. You can set it up using your Android phone's browser; you do not need a PC to run the cloud build.

## Honest feature status

**Included in this project:**
- Android Kotlin + Jetpack Compose app scaffold
- Dark emerald chat UI and starter prompts
- Local document/model file picker scaffolding
- Android manifest does not request the INTERNET permission
- GitHub Actions workflow to compile a debug APK and upload it as an artifact

**Not included yet:**
- A real local language-model inference engine
- Book parsing, retrieval, and knowledge learning
- Voice recognition or offline speech output
- Vision/image understanding
- Local image generation

The app is currently a UI/starter scaffold, not the finished JADE AI. Building this APK does not automatically add an AI model. The model files and inference runtime must be integrated separately. This workflow builds the app; GitHub Actions itself needs internet to download build tools and dependencies, but the installed app is designed not to require a network connection.

## Build it from an Android phone

### 1. Create a GitHub repository
1. Open https://github.com in your phone browser and sign in or create an account.
2. Create a new repository named `jade-android`.
3. For the easiest setup, make it **Private** if you do not want the source code public. Keep in mind GitHub account limits and repository settings may affect Actions availability.
4. Do not initialize it with a README if you plan to upload all project files from this ZIP.

### 2. Upload the project files
1. Download and extract `JADE_Cloud_Build.zip` on your phone. If your file manager cannot extract it, use a trusted archive utility.
2. In your new repository, choose **Add file → Upload files**.
3. Upload the *contents* of the extracted `JADE_Cloud_Build` folder, including the hidden `.github` folder and `.github/workflows/android-apk.yml`. The repository root should directly contain `app`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, and `.github`.
4. Commit the files to `main`.

**Important:** Some mobile file pickers hide dot-folders such as `.github`. If you cannot upload `.github/workflows/android-apk.yml`, use GitHub's web editor to create that exact path and paste the workflow from this project. The build will not run automatically without the workflow file.

### 3. Run the cloud build
1. In the repository, open the **Actions** tab.
2. If prompted, enable GitHub Actions for the repository.
3. Select **Build JADE Android APK** on the left.
4. Tap **Run workflow**, choose `main`, then run it. A push to `main` also triggers a build.
5. Wait for the workflow to finish. If it fails, open the run and inspect the failed step's log; do not assume an APK exists when the run is red.

### 4. Download and install the APK
1. Open the successful workflow run.
2. Scroll to **Artifacts** and download `JADE-debug-apk`.
3. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.
4. Tap `app-debug.apk` to install. Android may ask you to allow your browser or file manager to **Install unknown apps**. Enable that permission only for the app you trust, install JADE, and turn the permission off again if you prefer.
5. If Android blocks installation, check that the download completed, enough storage is available, and the device supports Android 8.0 or later (this project's minimum SDK is 26).

## What this build is for

This is a **debug/test APK**, signed with Android's debug key by the build system. It is suitable for personal testing, not a production release. Do not share it as a trusted production build. A later release should use a private signing key kept out of the repository and GitHub logs.

## Technical notes

- Android Gradle Plugin: 8.7.3
- Java: 17
- Cloud Gradle version: 8.9
- APK task: `assembleDebug`
- Artifact path: `app/build/outputs/apk/debug/app-debug.apk`
- The workflow uses GitHub Actions and uploads the resulting APK as an artifact for 14 days.

Official references:
- Android command-line APK builds: https://developer.android.com/build/building-cmdline
- Gradle on GitHub Actions: https://docs.gradle.org/current/userguide/github-actions.html
